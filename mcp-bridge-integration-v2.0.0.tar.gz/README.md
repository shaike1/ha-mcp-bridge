# MCP Bridge Integration v2.0.0

🤖 **Advanced Home Assistant Integration for Claude.ai with Direct Core Access**

[![GitHub Release](https://img.shields.io/github/release/shaike1/ha-mcp-bridge-integration.svg?style=flat-square)](https://github.com/shaike1/ha-mcp-bridge-integration/releases)
[![HACS](https://img.shields.io/badge/HACS-Custom-orange.svg?style=flat-square)](https://github.com/custom-components/hacs)
[![License](https://img.shields.io/github/license/shaike1/ha-mcp-bridge-integration.svg?style=flat-square)](LICENSE)

This custom integration provides **direct Home Assistant core access** for the MCP Bridge add-on, enabling advanced automation management, dynamic scene creation, and intelligent dashboard generation through Claude.ai.

## 🚀 Features

### **🎯 Direct HA Core Access**
- ✅ **Zero API overhead** - Direct service calls to HA core
- ✅ **Real-time entity capabilities** - Cached device and entity information  
- ✅ **Advanced automation templates** - Pre-built automation patterns
- ✅ **Transaction-based operations** - Bulk device control with rollback

### **🛠️ Advanced Services**

#### **🎬 Dynamic Scene Creation**
Create complex scenes with advanced configurations:
```yaml
service: mcp_bridge.create_dynamic_scene
data:
  name: "Movie Night"
  entities:
    - entity_id: light.living_room
      state: "on"
      brightness: 100
      color_temp: 400
    - entity_id: climate.main
      state: "heat"
      temperature: 22
```

#### **🤖 Automation Management**
Create automations from templates with natural language:
```yaml
service: mcp_bridge.modify_automation
data:
  name: "Smart Motion Light"
  template: "motion_light"
  trigger_entity: binary_sensor.motion_detector
  target_entity: light.hallway
```

#### **🔄 Bulk Device Control**
Control multiple devices atomically:
```yaml
service: mcp_bridge.bulk_device_control
data:
  rollback_on_error: true
  operations:
    - entity_id: light.bedroom_1
      action: "turn_on"
      params: {brightness: 200}
    - entity_id: light.bedroom_2  
      action: "turn_on"
      params: {brightness: 200}
```

#### **📊 Dashboard Generation**
Generate Lovelace dashboards automatically:
```yaml
service: mcp_bridge.generate_dashboard
data:
  title: "Living Room Control"
  area_id: "living_room"
  type: "room"
```

### **📊 Monitoring & Status**
- `sensor.mcp_bridge_integration_status` - Integration status and metrics
- `sensor.mcp_bridge_capabilities` - Available capabilities and features

## 📦 Installation

### **Method 1: HACS (Recommended)**
1. Open **HACS** in Home Assistant
2. Go to **Integrations** → **⋮** → **Custom repositories**
3. Add repository: `https://github.com/shaike1/ha-mcp-bridge-integration`
4. Category: **Integration**
5. **Download** and **Restart** Home Assistant
6. Go to **Settings** → **Devices & Services** → **Add Integration**
7. Search for **"MCP Bridge Integration"**

### **Method 2: Manual Installation**
1. Download the `custom_components/mcp_bridge/` folder
2. Copy to your Home Assistant `config/custom_components/` directory
3. **Restart** Home Assistant
4. **Add integration** via Settings → Integrations

## 🔗 Hybrid Integration with Add-on

This integration works seamlessly with the **HA MCP Bridge Enhanced** add-on:

1. **🏠 Add-on** handles MCP protocol and Claude.ai communication
2. **⚡ Integration** provides advanced HA core capabilities  
3. **🔗 Hybrid Bridge** enables seamless communication between components

**Get the Add-on:** https://github.com/shaike1/haos-mcp

### **🎯 How the Hybrid System Works:**

```mermaid
graph LR
    A[Claude.ai] --> B[MCP Bridge Add-on]
    B --> C{Integration Available?}
    C -->|Yes| D[Advanced Tools → Integration]
    C -->|No| E[Basic Tools → Add-on]
    D --> F[Direct HA Core Access]
    E --> G[HA REST API]
```

## 🛠️ Configuration

1. **Install the Integration**
2. **Go to:** Settings → Integrations
3. **Add Integration** → Search "MCP Bridge"
4. **Enable advanced features** (recommended)
5. **Auto-discover add-on** (if installed)

## 📊 Claude.ai Integration

When used with the enhanced add-on, Claude.ai can now:

- 🎬 **Create complex scenes** based on natural language descriptions
- 🤖 **Generate automations** from simple text instructions
- 🔄 **Control multiple devices** in coordinated actions
- 📊 **Build custom dashboards** for specific rooms or purposes

### **Example Claude Commands:**
- *"Create a movie night scene with dim warm lighting and comfortable temperature"*
- *"Set up an automation that turns on the hallway light when motion is detected"*  
- *"Control all bedroom lights together and make them warm white"*
- *"Generate a dashboard for the living room with lights and climate controls"*

## 🔧 Advanced Usage

### **Entity Capabilities Cache**
The integration maintains a comprehensive cache of:
- 🔍 **Device information** - Manufacturer, model, identifiers
- 🏠 **Area assignments** - Room and location mapping
- ⚡ **Supported features** - Available actions and capabilities
- 📊 **Real-time attributes** - Current state and configuration

### **API Communication**
When the add-on is installed, it can communicate with this integration via:
- `GET /api/mcp_bridge/status` - Integration status
- `POST /api/mcp_bridge/{service}` - Execute advanced services
- `GET /api/mcp_bridge/capabilities` - Available capabilities

## 🐛 Troubleshooting

**Integration not loading:**
- Check Home Assistant logs for errors
- Ensure all dependencies are installed
- Verify Home Assistant version ≥ 2023.1.0

**Services not available:**
- Restart Home Assistant after installation
- Check that integration is properly configured in UI
- Verify no conflicts with other integrations

**Add-on communication issues:**
- Ensure both add-on and integration are running
- Check add-on logs for connection errors
- Verify API endpoints are accessible

## 📞 Support

- **🐛 Issues:** [GitHub Issues](https://github.com/shaike1/ha-mcp-bridge-integration/issues)
- **📖 Documentation:** [Full Guide](https://github.com/shaike1/haos-mcp)
- **💬 Community:** [Home Assistant Community](https://community.home-assistant.io/)
- **🏠 Add-on Repository:** [HA MCP Bridge Add-on](https://github.com/shaike1/haos-mcp)

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## ⭐ Credits

- **🤖 Claude.ai** - AI assistant integration
- **🏠 Home Assistant** - Smart home platform
- **👥 Community** - Feature requests and testing

---

**🎯 Part of the MCP Bridge Ecosystem**  
**🔗 Works with:** [HA MCP Bridge Add-on](https://github.com/shaike1/haos-mcp)  
**🏪 Available via:** HACS Custom Repository