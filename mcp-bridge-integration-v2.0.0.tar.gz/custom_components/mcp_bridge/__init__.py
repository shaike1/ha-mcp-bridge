"""
MCP Bridge Integration for Home Assistant.

Provides direct core access for the MCP Bridge add-on with advanced automation,
scene management, and dashboard generation capabilities.
"""
import logging
import asyncio
from datetime import timedelta

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.helpers.event import async_track_time_interval
from homeassistant.const import Platform

from .const import DOMAIN
from .coordinator import MCPBridgeCoordinator
from .services import async_register_services
from .api import async_register_api

_LOGGER = logging.getLogger(__name__)

PLATFORMS = [Platform.SENSOR]

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up MCP Bridge from a config entry."""
    _LOGGER.info("Setting up MCP Bridge Integration v2.0.0")
    
    # Initialize the coordinator for core HA access
    coordinator = MCPBridgeCoordinator(hass, entry)
    
    # Store coordinator in hass data
    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN][entry.entry_id] = {
        "coordinator": coordinator
    }
    
    # Initialize the coordinator
    # Initialize the coordinator
    await coordinator.async_setup()
    
    # Perform first refresh to populate coordinator data
    await coordinator.async_config_entry_first_refresh()
        # Register advanced services
    await async_register_services(hass, coordinator)
    
    # Register API endpoints for add-on communication
    await async_register_api(hass)
    
    # Set up platforms
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    
    _LOGGER.info("MCP Bridge Integration setup complete - API bridge enabled")
    return True

async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    if unload_ok := await hass.config_entries.async_unload_platforms(entry, PLATFORMS):
        coordinator = hass.data[DOMAIN][entry.entry_id]["coordinator"]
        await coordinator.async_unload()
        hass.data[DOMAIN].pop(entry.entry_id)
    
    return unload_ok