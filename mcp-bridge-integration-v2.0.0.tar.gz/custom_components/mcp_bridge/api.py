"""API endpoints for MCP Bridge Integration communication."""
import logging
from typing import Any, Dict

from aiohttp import web
from homeassistant.components.http import HomeAssistantView
from homeassistant.core import HomeAssistant

from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

class MCPBridgeAPIView(HomeAssistantView):
    """API view for MCP Bridge communication."""
    
    url = "/api/mcp_bridge/{endpoint}"
    name = "api:mcp_bridge"
    requires_auth = True

    def __init__(self, hass: HomeAssistant):
        """Initialize the API view."""
        self.hass = hass

    async def get(self, request: web.Request, endpoint: str) -> web.Response:
        """Handle GET requests."""
        
        if endpoint == "status":
            return self.json({
                "status": "active",
                "integration_version": "2.0.0",
                "capabilities": await self._get_capabilities(),
                "services": await self._get_services()
            })
        
        elif endpoint == "capabilities":
            return self.json(await self._get_capabilities())
        
        elif endpoint == "services":
            return self.json(await self._get_services())
        
        else:
            return self.json({"error": "Unknown endpoint"}, status_code=404)

    async def post(self, request: web.Request, endpoint: str) -> web.Response:
        """Handle POST requests for service calls."""
        
        try:
            data = await request.json()
        except Exception as e:
            return self.json({"error": f"Invalid JSON: {str(e)}"}, status_code=400)
        
        # Get coordinator from integration data
        config_entries = self.hass.config_entries.async_entries(DOMAIN)
        if not config_entries:
            return self.json({"error": "Integration not configured"}, status_code=503)
        
        coordinator = self.hass.data[DOMAIN][config_entries[0].entry_id]["coordinator"]
        
        try:
            if endpoint == "create_dynamic_scene":
                result = await coordinator.create_dynamic_scene(data)
                return self.json({"success": True, "result": result})
            
            elif endpoint == "modify_automation":
                result = await coordinator.modify_automation(data)
                return self.json({"success": True, "result": result})
            
            elif endpoint == "bulk_device_control":
                result = await coordinator.bulk_device_control(data)
                return self.json({"success": True, "result": result})
            
            elif endpoint == "generate_dashboard":
                result = await coordinator.generate_dashboard_config(data)
                return self.json({"success": True, "result": result})
            
            else:
                return self.json({"error": f"Unknown service: {endpoint}"}, status_code=404)
                
        except Exception as e:
            _LOGGER.error(f"Error executing {endpoint}: {str(e)}")
            return self.json({"error": str(e)}, status_code=500)

    async def _get_capabilities(self) -> Dict[str, Any]:
        """Get integration capabilities."""
        return {
            "dynamic_scene_creation": True,
            "automation_management": True,
            "bulk_device_control": True,
            "dashboard_generation": True,
            "energy_analysis": True,
            "automation_optimization": True,
            "direct_core_access": True,
            "api_communication": True
        }

    async def _get_services(self) -> Dict[str, Any]:
        """Get available services."""
        return {
            "create_dynamic_scene": "Create dynamic scenes with complex configurations",
            "modify_automation": "Create or modify automations with templates",
            "bulk_device_control": "Control multiple devices with transaction support",
            "generate_dashboard": "Generate Lovelace dashboard configurations",
            "analyze_energy": "Analyze energy usage patterns",
            "optimize_automations": "Optimize existing automations"
        }

async def async_register_api(hass: HomeAssistant) -> None:
    """Register API endpoints."""
    api_view = MCPBridgeAPIView(hass)
    hass.http.register_view(api_view)
    _LOGGER.info("MCP Bridge API endpoints registered")