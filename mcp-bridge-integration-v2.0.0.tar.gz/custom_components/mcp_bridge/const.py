"""Constants for the MCP Bridge integration."""

DOMAIN = "mcp_bridge"

# Service names
SERVICE_CREATE_SCENE = "create_dynamic_scene"
SERVICE_MODIFY_AUTOMATION = "modify_automation"
SERVICE_BULK_CONTROL = "bulk_device_control"
SERVICE_GENERATE_DASHBOARD = "generate_dashboard"
SERVICE_ANALYZE_ENERGY = "analyze_energy_usage"
SERVICE_OPTIMIZE_AUTOMATIONS = "optimize_automations"

# Default values
DEFAULT_UPDATE_INTERVAL = 30
DEFAULT_MAX_ENTITIES = 1000

# API endpoints for add-on communication
ADDON_API_BASE = "http://addon_ha_mcp_bridge:3003"
ADDON_TOOLS_ENDPOINT = f"{ADDON_API_BASE}/tools"
ADDON_STATUS_ENDPOINT = f"{ADDON_API_BASE}/status"