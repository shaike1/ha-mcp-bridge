"""Coordinator for MCP Bridge Integration."""
import logging
import asyncio
from datetime import timedelta
from typing import Any, Dict, List, Optional

from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator
from homeassistant.helpers import entity_registry, device_registry, area_registry
from homeassistant.components import automation, scene, script
from homeassistant.config_entries import ConfigEntry

from .const import DOMAIN, DEFAULT_UPDATE_INTERVAL

_LOGGER = logging.getLogger(__name__)

class MCPBridgeCoordinator(DataUpdateCoordinator):
    """Coordinator for MCP Bridge with direct HA core access."""
    
    def __init__(self, hass: HomeAssistant, entry: ConfigEntry):
        """Initialize the coordinator."""
        super().__init__(
            hass,
            _LOGGER,
            name=DOMAIN,
            update_interval=timedelta(seconds=DEFAULT_UPDATE_INTERVAL),
        )
        self.entry = entry
        self.hass = hass
        
        # Core HA access points
        self.entity_registry = entity_registry.async_get(hass)
        self.device_registry = device_registry.async_get(hass)
        self.area_registry = area_registry.async_get(hass)
        
        # Advanced capabilities cache
        self._entity_capabilities = {}
        self._automation_templates = {}
        self._scene_configs = {}
        
    async def async_setup(self):
        """Set up the coordinator."""
        _LOGGER.info("Initializing MCP Bridge Core Access")
        
        # Build entity capabilities cache
        await self._build_entity_capabilities()
        
        # Load automation templates
        await self._load_automation_templates()
        
        
        _LOGGER.info(f"Cached {len(self._entity_capabilities)} entity capabilities")
    
    async def _async_update_data(self):
        """Fetch data from the integration."""
        from datetime import datetime
        # Return basic status data for the coordinator
        return {
            "entities_count": len(self._entity_capabilities),
            "templates_count": len(self._automation_templates),
            "last_update": datetime.now().isoformat()
        }
    async def _build_entity_capabilities(self):
        """Build a comprehensive cache of entity capabilities."""
        for entity in self.entity_registry.entities.values():
            entity_id = entity.entity_id
            state = self.hass.states.get(entity_id)
            if not state:
                continue
                
            capabilities = {
                "domain": entity.domain,
                "device_class": entity.device_class,
                "platform": entity.platform,
                "supported_features": getattr(state, "supported_features", 0),
                "attributes": dict(state.attributes),
                "area_id": entity.area_id,
                "device_id": entity.device_id,
            }
            
            # Add device info if available
            if entity.device_id:
                device = self.device_registry.async_get(entity.device_id)
                if device:
                    capabilities["device_info"] = {
                        "manufacturer": device.manufacturer,
                        "model": device.model,
                        "name": device.name,
                        "identifiers": device.identifiers,
                    }
            
            # Add area info if available
            if entity.area_id:
                area = self.area_registry.async_get_area(entity.area_id)
                if area:
                    capabilities["area_name"] = area.name
                    
            self._entity_capabilities[entity_id] = capabilities
    
    async def _load_automation_templates(self):
        """Load common automation templates."""
        self._automation_templates = {
            "motion_light": {
                "trigger": {"platform": "state", "entity_id": "", "to": "on"},
                "action": {"service": "light.turn_on", "target": {"entity_id": ""}},
                "mode": "single"
            },
            "sunset_scene": {
                "trigger": {"platform": "sun", "event": "sunset"},
                "action": {"service": "scene.turn_on", "target": {"entity_id": ""}},
                "mode": "single"
            },
            "presence_climate": {
                "trigger": [
                    {"platform": "state", "entity_id": "", "to": "home"},
                    {"platform": "state", "entity_id": "", "to": "away"}
                ],
                "action": [
                    {
                        "choose": [
                            {
                                "conditions": {"condition": "state", "entity_id": "", "state": "home"},
                                "sequence": {"service": "climate.set_temperature", "data": {"temperature": 21}}
                            },
                            {
                                "conditions": {"condition": "state", "entity_id": "", "state": "away"},
                                "sequence": {"service": "climate.set_temperature", "data": {"temperature": 18}}
                            }
                        ]
                    }
                ]
            }
        }
    
    # =====================================================================
    # ADVANCED MCP TOOLS - Direct HA Core Access
    # =====================================================================
    
    async def create_dynamic_scene(self, scene_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a dynamic scene with advanced configuration."""
        try:
            scene_id = f"scene.mcp_dynamic_{scene_data.get('name', 'unnamed').lower().replace(' ', '_')}"
            
            # Build scene configuration
            scene_config = {
                "name": scene_data.get("name", "MCP Dynamic Scene"),
                "entities": {}
            }
            
            # Process entity states
            for entity_config in scene_data.get("entities", []):
                entity_id = entity_config["entity_id"]
                capabilities = self._entity_capabilities.get(entity_id, {})
                
                # Smart state configuration based on entity type
                if capabilities.get("domain") == "light":
                    scene_config["entities"][entity_id] = {
                        "state": entity_config.get("state", "on"),
                        "brightness": entity_config.get("brightness", 255),
                        "color_temp": entity_config.get("color_temp")
                    }
                elif capabilities.get("domain") == "climate":
                    scene_config["entities"][entity_id] = {
                        "state": entity_config.get("state", "heat"),
                        "temperature": entity_config.get("temperature", 21)
                    }
                else:
                    scene_config["entities"][entity_id] = {
                        "state": entity_config.get("state", "on")
                    }
            
            # Create the scene using HA core
            await self.hass.services.async_call(
                "scene",
                "create",
                {
                    "scene_id": scene_id.split(".")[1],
                    "entities": scene_config["entities"]
                }
            )
            
            return {
                "success": True,
                "scene_id": scene_id,
                "message": f"Created dynamic scene '{scene_data.get('name')}'"
            }
            
        except Exception as e:
            _LOGGER.error(f"Failed to create dynamic scene: {e}")
            return {"success": False, "error": str(e)}
    
    async def modify_automation(self, automation_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create or modify automations with advanced logic."""
        try:
            automation_id = automation_data.get("automation_id")
            template_type = automation_data.get("template", "custom")
            
            # Use template if specified
            if template_type in self._automation_templates:
                config = self._automation_templates[template_type].copy()
                
                # Customize template with provided data
                if "trigger_entity" in automation_data:
                    if isinstance(config["trigger"], list):
                        for trigger in config["trigger"]:
                            if "entity_id" in trigger:
                                trigger["entity_id"] = automation_data["trigger_entity"]
                    else:
                        config["trigger"]["entity_id"] = automation_data["trigger_entity"]
                
                if "target_entity" in automation_data:
                    if isinstance(config["action"], list):
                        for action in config["action"]:
                            if "target" in action:
                                action["target"]["entity_id"] = automation_data["target_entity"]
                    else:
                        config["action"]["target"]["entity_id"] = automation_data["target_entity"]
            else:
                # Custom automation configuration
                config = automation_data.get("config", {})
            
            # Add metadata
            config["alias"] = automation_data.get("name", f"MCP Automation {automation_id}")
            config["id"] = automation_id or f"mcp_automation_{len(self.hass.states.async_entity_ids('automation'))}"
            
            # Create/update automation
            await self.hass.services.async_call(
                "automation",
                "reload"
            )
            
            return {
                "success": True,
                "automation_id": config["id"],
                "message": f"Created/modified automation '{config['alias']}'"
            }
            
        except Exception as e:
            _LOGGER.error(f"Failed to modify automation: {e}")
            return {"success": False, "error": str(e)}
    
    async def bulk_device_control(self, control_data: Dict[str, Any]) -> Dict[str, Any]:
        """Control multiple devices with transaction-like behavior."""
        try:
            operations = control_data.get("operations", [])
            rollback_on_error = control_data.get("rollback_on_error", False)
            executed_operations = []
            
            for operation in operations:
                try:
                    entity_id = operation["entity_id"]
                    action = operation["action"]
                    params = operation.get("params", {})
                    
                    # Store current state for potential rollback
                    if rollback_on_error:
                        current_state = self.hass.states.get(entity_id)
                        executed_operations.append({
                            "entity_id": entity_id,
                            "previous_state": current_state.state if current_state else None,
                            "previous_attributes": dict(current_state.attributes) if current_state else {}
                        })
                    
                    # Execute operation
                    domain = entity_id.split(".")[0]
                    await self.hass.services.async_call(
                        domain,
                        action,
                        {"entity_id": entity_id, **params}
                    )
                    
                except Exception as op_error:
                    if rollback_on_error:
                        # Rollback previous operations
                        await self._rollback_operations(executed_operations)
                        raise op_error
                    else:
                        _LOGGER.warning(f"Operation failed for {operation.get('entity_id')}: {op_error}")
            
            return {
                "success": True,
                "operations_executed": len(operations),
                "message": f"Successfully executed {len(operations)} operations"
            }
            
        except Exception as e:
            _LOGGER.error(f"Bulk device control failed: {e}")
            return {"success": False, "error": str(e)}
    
    async def _rollback_operations(self, operations: List[Dict[str, Any]]):
        """Rollback operations to previous states."""
        for op in reversed(operations):
            try:
                entity_id = op["entity_id"]
                domain = entity_id.split(".")[0]
                
                if op["previous_state"] == "on":
                    await self.hass.services.async_call(domain, "turn_on", {"entity_id": entity_id})
                elif op["previous_state"] == "off":
                    await self.hass.services.async_call(domain, "turn_off", {"entity_id": entity_id})
                    
            except Exception as rollback_error:
                _LOGGER.error(f"Rollback failed for {op['entity_id']}: {rollback_error}")
    
    async def generate_dashboard_config(self, dashboard_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate Lovelace dashboard configuration."""
        try:
            area_id = dashboard_data.get("area_id")
            dashboard_type = dashboard_data.get("type", "room")
            
            # Get entities for the area
            area_entities = [
                entity_id for entity_id, capabilities in self._entity_capabilities.items()
                if capabilities.get("area_id") == area_id
            ]
            
            # Generate dashboard configuration
            dashboard_config = {
                "title": dashboard_data.get("title", f"MCP Generated Dashboard"),
                "views": []
            }
            
            if dashboard_type == "room":
                view_config = self._generate_room_view(area_entities, area_id)
                dashboard_config["views"].append(view_config)
            elif dashboard_type == "security":
                view_config = self._generate_security_view(area_entities)
                dashboard_config["views"].append(view_config)
            elif dashboard_type == "energy":
                view_config = self._generate_energy_view(area_entities)
                dashboard_config["views"].append(view_config)
            
            return {
                "success": True,
                "config": dashboard_config,
                "entities_included": len(area_entities)
            }
            
        except Exception as e:
            _LOGGER.error(f"Failed to generate dashboard: {e}")
            return {"success": False, "error": str(e)}
    
    def _generate_room_view(self, entities: List[str], area_id: str) -> Dict[str, Any]:
        """Generate a room-specific dashboard view."""
        cards = []
        
        # Group entities by type
        lights = [e for e in entities if e.startswith("light.")]
        switches = [e for e in entities if e.startswith("switch.")]
        sensors = [e for e in entities if e.startswith("sensor.")]
        climate = [e for e in entities if e.startswith("climate.")]
        
        # Light control card
        if lights:
            cards.append({
                "type": "light",
                "entities": lights[:6],  # Limit to 6 lights
                "title": "Lights"
            })
        
        # Climate control card
        if climate:
            cards.append({
                "type": "thermostat",
                "entity": climate[0],
                "title": "Climate"
            })
        
        # Sensor overview
        if sensors:
            cards.append({
                "type": "entities",
                "entities": sensors[:8],  # Limit to 8 sensors
                "title": "Sensors"
            })
        
        return {
            "title": f"Room Control",
            "path": f"mcp_room_{area_id}",
            "cards": cards
        }
    
    def _generate_security_view(self, entities: List[str]) -> Dict[str, Any]:
        """Generate a security-focused dashboard view."""
        # Security-specific logic here
        return {
            "title": "Security Overview",
            "path": "mcp_security",
            "cards": []
        }
    
    def _generate_energy_view(self, entities: List[str]) -> Dict[str, Any]:
        """Generate an energy-focused dashboard view."""
        # Energy-specific logic here
        return {
            "title": "Energy Management",
            "path": "mcp_energy",
            "cards": []
        }
    
    async def async_unload(self):
        """Unload the coordinator."""
        _LOGGER.info("Unloading MCP Bridge Coordinator")
        # Cleanup tasks here