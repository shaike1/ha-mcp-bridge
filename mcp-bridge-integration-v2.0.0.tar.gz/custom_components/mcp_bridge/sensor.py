"""Sensor platform for MCP Bridge Integration."""
import logging
from datetime import timedelta

from homeassistant.components.sensor import SensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up MCP Bridge sensors from a config entry."""
    coordinator = hass.data[DOMAIN][config_entry.entry_id]["coordinator"]
    
    sensors = [
        MCPBridgeStatusSensor(coordinator),
        MCPBridgeCapabilitiesSensor(coordinator),
    ]
    
    async_add_entities(sensors)

class MCPBridgeStatusSensor(SensorEntity):
    """Sensor for MCP Bridge integration status."""
    
    def __init__(self, coordinator):
        """Initialize the sensor."""
        self._coordinator = coordinator
        self._attr_name = "MCP Bridge Integration Status"
        self._attr_unique_id = f"{DOMAIN}_status"
        
    @property
    def state(self):
        """Return the state of the sensor."""
        return "active"
    
    @property
    def extra_state_attributes(self):
        """Return additional state attributes."""
        return {
            "entities_cached": len(self._coordinator._entity_capabilities),
            "automation_templates": len(self._coordinator._automation_templates),
            "version": "2.0.0",
            "core_access": True,
        }

class MCPBridgeCapabilitiesSensor(SensorEntity):
    """Sensor showing available MCP capabilities."""
    
    def __init__(self, coordinator):
        """Initialize the sensor."""
        self._coordinator = coordinator
        self._attr_name = "MCP Bridge Capabilities"
        self._attr_unique_id = f"{DOMAIN}_capabilities"
        
    @property
    def state(self):
        """Return the number of available capabilities."""
        return 6  # Number of services
    
    @property
    def extra_state_attributes(self):
        """Return available capabilities."""
        return {
            "dynamic_scene_creation": True,
            "automation_management": True,
            "bulk_device_control": True,
            "dashboard_generation": True,
            "energy_analysis": True,
            "automation_optimization": True,
            "direct_core_access": True,
        }