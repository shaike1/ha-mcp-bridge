"""Service registration for MCP Bridge Integration."""
import logging
import voluptuous as vol

from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.helpers import config_validation as cv

from .const import (
    DOMAIN,
    SERVICE_CREATE_SCENE,
    SERVICE_MODIFY_AUTOMATION,
    SERVICE_BULK_CONTROL,
    SERVICE_GENERATE_DASHBOARD,
    SERVICE_ANALYZE_ENERGY,
    SERVICE_OPTIMIZE_AUTOMATIONS,
)

_LOGGER = logging.getLogger(__name__)

# Service schemas
CREATE_SCENE_SCHEMA = vol.Schema({
    vol.Required("name"): cv.string,
    vol.Required("entities"): vol.All(cv.ensure_list, [vol.Schema({
        vol.Required("entity_id"): cv.entity_id,
        vol.Optional("state"): cv.string,
        vol.Optional("brightness"): vol.Range(min=1, max=255),
        vol.Optional("color_temp"): vol.Range(min=153, max=500),
        vol.Optional("temperature"): vol.Range(min=5, max=35),
    })])
})

MODIFY_AUTOMATION_SCHEMA = vol.Schema({
    vol.Optional("automation_id"): cv.string,
    vol.Required("name"): cv.string,
    vol.Optional("template"): vol.In(["motion_light", "sunset_scene", "presence_climate", "custom"]),
    vol.Optional("trigger_entity"): cv.entity_id,
    vol.Optional("target_entity"): cv.entity_id,
    vol.Optional("config"): dict,
})

BULK_CONTROL_SCHEMA = vol.Schema({
    vol.Required("operations"): vol.All(cv.ensure_list, [vol.Schema({
        vol.Required("entity_id"): cv.entity_id,
        vol.Required("action"): cv.string,
        vol.Optional("params"): dict,
    })]),
    vol.Optional("rollback_on_error", default=False): cv.boolean,
})

GENERATE_DASHBOARD_SCHEMA = vol.Schema({
    vol.Required("title"): cv.string,
    vol.Optional("area_id"): cv.string,
    vol.Optional("type", default="room"): vol.In(["room", "security", "energy"]),
})

async def async_register_services(hass: HomeAssistant, coordinator) -> None:
    """Register MCP Bridge services."""
    
    async def create_dynamic_scene(call: ServiceCall) -> None:
        """Service to create dynamic scenes."""
        result = await coordinator.create_dynamic_scene(call.data)
        _LOGGER.info(f"Dynamic scene creation result: {result}")
    
    async def modify_automation(call: ServiceCall) -> None:
        """Service to modify automations."""
        result = await coordinator.modify_automation(call.data)
        _LOGGER.info(f"Automation modification result: {result}")
    
    async def bulk_device_control(call: ServiceCall) -> None:
        """Service for bulk device control."""
        result = await coordinator.bulk_device_control(call.data)
        _LOGGER.info(f"Bulk control result: {result}")
    
    async def generate_dashboard(call: ServiceCall) -> None:
        """Service to generate dashboard configurations."""
        result = await coordinator.generate_dashboard_config(call.data)
        _LOGGER.info(f"Dashboard generation result: {result}")
    
    async def analyze_energy_usage(call: ServiceCall) -> None:
        """Service to analyze energy usage patterns."""
        # Advanced energy analysis implementation
        _LOGGER.info("Energy analysis service called")
    
    async def optimize_automations(call: ServiceCall) -> None:
        """Service to optimize existing automations."""
        # Automation optimization implementation
        _LOGGER.info("Automation optimization service called")
    
    # Register all services
    hass.services.async_register(
        DOMAIN,
        SERVICE_CREATE_SCENE,
        create_dynamic_scene,
        schema=CREATE_SCENE_SCHEMA,
    )
    
    hass.services.async_register(
        DOMAIN,
        SERVICE_MODIFY_AUTOMATION,
        modify_automation,
        schema=MODIFY_AUTOMATION_SCHEMA,
    )
    
    hass.services.async_register(
        DOMAIN,
        SERVICE_BULK_CONTROL,
        bulk_device_control,
        schema=BULK_CONTROL_SCHEMA,
    )
    
    hass.services.async_register(
        DOMAIN,
        SERVICE_GENERATE_DASHBOARD,
        generate_dashboard,
        schema=GENERATE_DASHBOARD_SCHEMA,
    )
    
    hass.services.async_register(
        DOMAIN,
        SERVICE_ANALYZE_ENERGY,
        analyze_energy_usage,
    )
    
    hass.services.async_register(
        DOMAIN,
        SERVICE_OPTIMIZE_AUTOMATIONS,
        optimize_automations,
    )
    
    _LOGGER.info("Registered 6 advanced MCP Bridge services")